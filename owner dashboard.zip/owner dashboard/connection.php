<?php
//connection file

$connection=mysqli_connect('localhost','root','','journey');

?>