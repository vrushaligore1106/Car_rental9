<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div  class="card--container" id="approvals" >
            <h3 class="main--title"> Approvals</h3>
            <div class="card--wrapper" >
                <div class="prev--card">
                    <div class="card--header">
                        <div class="amount">
                            <span class="title">Booking Date  dd/mm//yy</span><br>
                            <span class="title">Location   Pune to Mumbai</span>
                            <span class="title">Vehicel Name Swift Desire</span>
                            <span class="title">Driver Name   Vishal abc</span><br>
                            <span class="amount--value">Rs 500.00</span>
                        </div>
                        <!-- <i class="icon">Rs</i> -->
                    </div>
                    <!-- <span class="card-detail">*** **** 3433</span> -->
                </div>
                
            </div>
        </div>
</body>
</html>