<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="slider-container">
  <div class="slider">
    <div class="slide">
      <img src="img2/img/Mahindra_XUV-removebg-preview.png" alt="Slide 1">
      <div class="slide-content">
        <!-- <h2>Slide 1</h2> -->
        <!-- <p>This is the first slide with some text.</p> -->
      </div>
    </div>
    <div class="slide">
      <img src="img2/img/Renault_Duster-removebg-preview.png" alt="Slide 2">
      <!-- <div class="slide-content"> -->
        <!-- <h2>Slide 2</h2> -->
        <p>Here is the second slide with different text.</p>
      </div>
    </div>
    <!-- Add more slides as needed -->
  </div>

  <!-- Navigation arrows -->
   
      <div class="prev" onclick="prevSlide()"><</div>
      <div class="next" onclick="nextSlide()">></div>
    
  </div>

        <div class="container">
          <div class="title">PRODUCT LIST</div>
          <div class="listProduct"></div>
        </div>
      
      <script>
        let currentIndex = 0;
      
        function showSlide(index) {
          const slider = document.querySelector('.slider');
          const slides = document.querySelectorAll('.slide');
          const totalSlides = slides.length;
      
          if (index < 0) {
            currentIndex = totalSlides - 1;
          } else if (index >= totalSlides) {
            currentIndex = 0;
          } else {
            currentIndex = index;
          }
      
          const newTransformValue = -currentIndex * 100 + '%';
          slider.style.transform = 'translateX(' + newTransformValue + ')';
        }
      
        function prevSlide() {
          showSlide(currentIndex - 1);
        }
      
        function nextSlide() {
          showSlide(currentIndex + 1);
        }
      
        // Auto-play the slider
        setInterval(nextSlide, 5000);
      



    

   
        //Important note: If you have downloaded the code
        // but still encounter errors when running the program,
         //    please watch the video at this link because
        // I have shown you how to run the project properly.
        // https://www.youtube.com/watch?v=okyfcpZfPAU&t=142s
        let products = null;
        // get datas from file json
        fetch('products.json')
            .then(response => response.json())
            .then(data => {
                products = data;
                addDataToHTML();
        })

        function addDataToHTML(){
    // remove datas default from HTML
        let listProductHTML = document.querySelector('.listProduct');

        // add new datas
        if(products != null) // if has data
        {
            products.forEach(product => {
                let newProduct = document.createElement('a');
                newProduct.href = './detail.html?id=' + product.id;
                newProduct.classList.add('item');
                newProduct.innerHTML = 
                `<img src="${product.image}" alt="">
                <h2>${product.name}</h2>
                <div class="price">$${product.price}</div>`;
                listProductHTML.appendChild(newProduct);

            });
        }
    }

    </script>

</body>
<!-- <footer>
  <div class="column">
      <h2>Company</h2>
      <p><i class="fa-solid fa-greater-than"></i><a href="#">  About Us</a></p>
      <p><i class="fa-solid fa-greater-than"></i><a href="#">   Contact Us</a></p>
      <p><i class="fa-solid fa-greater-than"></i><a href="#">  Our Services</a></p>
      <p><i class="fa-solid fa-greater-than"></i><a href="#">   Privacy Policy</a></p>
      <p><i class="fa-solid fa-greater-than"></i><a href="#">  Terms & Condition</a></p>
  </div>

  <div class="column">
      <h2>Contact Info</h2>
      <p><i class="fa-solid fa-location-dot"></i><a href="#"> Allianze House, 2nd floor, Near old bird valley hotel HDFC colony, Pimpri Chinchwad, 411019, Pune, Maharashtra 411019</a></p>
      <p><i class="fa-solid fa-phone"></i><a href="#"> +91 9922111803</a></p>
      <p><i class="fa-solid fa-envelope"></i><a href="#"> hr@techviewinfotech.com</a></p>
  </div>

  <div class="column">
      <h2>Newsletter</h2>
      <p>Sign up for our newsletter to receive the latest news and updates.</p>
      <form action="#">
          <input type="text" placeholder="Enter your email">
          <input type="submit" value="Sign In">
      </form>
  </div>

  <div class="column">
      <h2>Follow Us</h2>
     <div class="footer-col">
         <h4>follow us</h4>
         <div class="social-links">
             <a href="#"><i class="fab fa-facebook-f"></i></a>
             <a href="#"><i class="fab fa-twitter"></i></a>
             <a href="https://www.instagram.com/techviewinfotech?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fab fa-instagram"></i></a>
             <a href="#"><i class="fab fa-linkedin-in"></i></a>
         </div>
     </div>
  </div>
</footer> -->
</html>


