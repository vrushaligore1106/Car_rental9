<?php
$servername = "localhost";
$username = "root";
$ownerPassword = "";
$dbname = "journey";

$conn = new mysqli($servername, $username, $ownerPassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['Explore'])) {
    $pickup_location = $_POST['pickup_location'];
    $drop_location = $_POST['drop_location'];
    $category = $_POST['Category'];
    $date = $_POST['date']; // Assuming you have a field named 'date' in your HTML form.

    // Insert data into the database
    $sql = "INSERT INTO booking_information (pickup_location, drop_location, category, date)
            VALUES ('$pickup_location', '$drop_location', '$category', '$date')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
