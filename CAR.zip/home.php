<?php
$servername = "localhost";
$username = "root";
$ownerPassword = "";
$dbname = "journey";

$conn = new mysqli($servername, $username, $ownerPassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fName = $_POST['fName'];
    $fEmail = $_POST['fEmail'];

    $fPhoneNO = $_POST['fPhoneNO'];
    $feedback = $_POST['feedback'];

    // Use prepared statements to prevent SQL injection
    $query = $conn->prepare("INSERT INTO feedback (fName, fEmail, fPhoneNO, feedback) 
                              VALUES (?, ?, ?, ?)");

    $query->bind_param("ssss", $fName, $fEmail, $fPhoneNO, $feedback);

    if ($query->execute()) {
        echo "Feedback Submitted successfully";
        echo "<script>";
        echo "window.location.href='home.php'";
        echo "</script>";
    } else {
        echo "Error: " . $query->error;
    }

    $query->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="./asset/Styles/home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Car Bike Rental</title>
    <script src="https://kit.fontawesome.com/0df6ecd121.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">


    <style>

    </style>

</head>

<body>
    <!-- Nav Bar -->
    <nav class="navbar">
               <!-- <div class="container"> -->
               <div class="left logo">
            <img src="./asset/images/logo.png" alt="logo">
        </div>
        <div class="right">
            <input type="checkbox" id="check">
            <label for="check" class="checkBtn">
                <i class="fa fa-bars" style="color: #fff;"></i>
            </label>
            <ul class="nav-items">
                <li class="nav-item"><a href="" class="navLink">Home</a></li>
                <li class="nav-item"><a href="./aboutUs/aboutus.php" class="navLink">About Us</a></li>
                <li class="nav-item"><a href="./ourServices/ourServices.php
                    " class="navLink">Service</a></li>
                <li class="nav-item"><a href="  packages/packagesOffer.php" class="navLink">Packages</a></li>
                <li class="nav-item"><a href="./contact/contact.php" class="navLink">Contact</a></li>
                <li class="nav-item"><a href="./Owner/OwnerRegistration.php" class="navLink">Add Vehicle</a></li>

                <?php
                session_start();

                // Assuming you've established a PDO connection earlier and stored it in $conn
                $conn = new PDO("mysql:host=localhost;dbname=journey", 'root', '');

                // Check if 'login' key is set in $_SESSION
                if (isset($_SESSION['login'])) {
                    $uid = $_SESSION['login'];
                    $fullName = $_SESSION['fullName'];      // Retrieve full name from session
                    $sql = "SELECT * FROM registration_form WHERE userID = :uid";
                    $query = $conn->prepare($sql);
                    $query->bindParam(':uid', $uid, PDO::PARAM_STR);
                    $query->execute();
                    $result = $query->fetchAll(PDO::FETCH_OBJ);

                    $cnt = 1;
                    if ($query->rowCount() > 0) {
                        foreach ($result as $row) {
                            echo '<li class="nav-item"><a href="../user dashboard/user_dashboard.php" class="navLink">' . $fullName . '</a></li>';
                            $cnt++;
                        }
                    } else {
                        echo '<li class="nav-item"><a href="User/Userlogin.php"><button class="btn">LogIn</button></a></li>';
                    }
                } else {
                    // Handle case when 'login' key is not set in $_SESSION
                    echo '<li class="nav-item"><a href="User/Userlogin.php"><button class="btn">LogIn</button></a></li>';
                }
                ?>

                <script>
                    document.addEventListener('DOMContentLoaded', function () {
                        var navItems = document.querySelectorAll('.nav-item');
                        navItems.forEach(function (navItem) {
                            navItem.addEventListener('click', function () {
                                // Redirect to user_dashboard/user_dashboard.php
                                window.location.href = 'user_dashboard/user_dashboard.php';
                            });
                        });
                    });
                </script>



            </ul>
        </div>
        <!-- </div> -->
    </nav>

    <!-- Home Banner  -->
    <div class="home booking-con">
        <img src="./asset/images/waveShape.png" alt="waveShape" class="home-img">
        <div class="container">
            <div class="home-con">
                <div class="wrapper">
                    <div class="static-txt">Journey Life Makes <br>Your Journey </div>
                    <ul class="dynamic-txts">
                        <li><span>AFFORDABLE</span></li>
                        <li><span>ADVENTURE</span></li>
                        <li><span>RELAXATION</span></li>
                        <li><span>EXPLORATION</span></li>
                        <li><span>EXCITEMENT</span></li>
                        <li><span>MEMORIES</span></li>
                    </ul>
                </div>
                <a href="#Booking"><button class="btn">Book Now !</button></a>
            </div>

            <div class="home-car" s>
                <img src="./asset/images/homeCar.png" alt="home-car">
            </div>
        </div>
    </div>

    <!-- Booking Form -->
    <div class="booking-con" id="Booking">
        <div class="container">
            <div class="booking-sec">

                <?php

                // session_start();

                // Check if the form has been submitted
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    // Store booking details in session variables
                    $_SESSION['booking_details'] = [
                        'pick_location' => $_POST['pick_location'],
                        'drop_location' => $_POST['drop_location'],
                        'Category' => $_POST['Category'],
                        'date' => $_POST['date'],
                        'pick_time' => $_POST['pick_time']
                    ];

                    // Redirect to booking_details.php
                    header('Location: booking.php');
                    exit();
                }
                ?>



                <form action="submitdb.php" method="POST" class="booking-form">

                    <h1 class="extra-lg">Book Here</h1>


                    <?php
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "journey";

                    $connection = mysqli_connect($servername, $username, $password, $dbname);


                    if (!$connection) {
                        die("Connection failed: " . mysqli_connect_error());
                    }
                    ?>


                    <div class="place-form">
                        <div class="dropd">
                            <label for="pick_location">Select an Pickup Location:</label>
                            <select id="pick_location" name="pick_location">
                                <?php
                                $query = "SELECT DISTINCT pick FROM location";
                                $result = mysqli_query($connection, $query);
                                if ($result) {

                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo '<option value="' . $row['pick'] . '">' . $row['pick'] . '</option>';
                                    }

                                    mysqli_free_result($result);
                                } else {
                                    echo "Error: " . mysqli_error($connection);
                                }
                                ?>

                            </select>
                        </div>



                        <?php
                        $query1 = "SELECT DISTINCT dropp FROM location";
                        $result = mysqli_query($connection, $query1);
                        if ($result) {
                            echo '<div class="place-form">';
                            echo '<div class="dropd">';
                            echo '<label for="drop_location">Select a drop-off location:</label>';
                            echo '<select id="drop_location" name="drop_location">';
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo '<option value="' . $row['dropp'] . '">' . $row['dropp'] . '</option>';
                            }
                            echo '</select>';
                            echo '</div>';
                            echo '</div>';
                            mysqli_free_result($result);
                        } else {
                            echo "Error: " . mysqli_error($connection);
                        }
                        ?>


                        <div class="dropd" style="display:none;">
                            <label for="distance">Distance:</label>
                            <input type="text" id="distance" name="distance" readonly>
                        </div>


                        <script>
                        document.getElementById("pick_location").addEventListener("change", calculateDistance);
                        document.getElementById("drop_location").addEventListener("change", calculateDistance);

                        function calculateDistance() {
                            var pick = document.getElementById("pick_location").value;
                            var drop = document.getElementById("drop_location").value;

                            var distanceMap = {
                                "kamshet_pune": 50,
                                "lonavala_pune": 60,
                                "dehuroad_pune": 30,
                                "chinchwad_pune": 20,
                                "talegaon_pune": 40,
                                "talegaon_chinchwad": 20,
                                "kamshet_chinchwad": 30,
                                "lonavala_chinchwad": 50,
                                "dehuroad_chinchwad": 10,
                            };

                            var key = pick.toLowerCase() + "_" + drop.toLowerCase();
                            var distance = distanceMap[key] || "N/A";

                            document.getElementById("distance").value = distance;
                        }
                        </script>


                        <div class="dropd">
                            <label for="Category">Select a Category:</label>
                            <select id="Category" name="Category">
                                <option value="Seden">Seden</option>
                                <option value="Prime Seden">Prime Seden</option>
                                <option value="Traveller">Traveller</option>
                            </select>
                        </div>


                        <div class="drop">
                            <label for="date">Select Date:</label>
                            <input type="date" name="date" class="form-control date" min="<?php echo date('Y-m-d'); ?>">
                        </div>

                        <div class="drop">
                            <label for="pick_time">Select Time:</label>
                            <input type="time" name="pick_time" class="form-control date">
                        </div>
                    </div>

                    <button type="submit" name="Explore" class="btn explore-btn"
                        onclick="redirectPage()">Explore</button>
                </form>
            </div>
        </div>



        <!-- Other Vehicles -->
        <div class="otherveliches">
            <h1 class="lg-heading">
                Other Vehicles Serices
            </h1>
            <div class="container card-container">
                <div class="cards">
                    <div class="card-img">
                        <img src="./asset/images/Seden.png" alt="bike&Scooter">
                    </div>
                    <div class="blog-title">
                        <h1 class="md-heading">2-4 Seater</h1>
                    </div>
                    <a href=""><button class="btn">Know More</button></a>
                </div>

                <div class="cards">
                    <div class="card-img">
                        <img src="./asset/images/Prime Seden.png" alt="Prime Seden">
                    </div>
                    <div class="blog-title">
                        <h1 class="md-heading">5-7 Seater</h1>
                    </div>
                    <a href=""><button class="btn">Know More</button></a>
                </div>

                <div class="cards">
                    <div class="card-img">
                        <img src="./asset/images/cruiser.png" alt="cruiser">
                    </div>
                    <div class="blog-title">
                        <h1 class="md-heading">7-9 Seater</h1>
                    </div>
                    <a href=""><button class="btn">Know More</button></a>
                </div>

                <div class="cards">
                    <div class="card-img">
                        <img src="./asset/images/traveller.png" alt="traveller">
                    </div>
                    <div class="blog-title">
                        <h1 class="md-heading">Traveller</h1>
                    </div>
                    <a href=""><button class="btn">Know More</button></a>
                </div>


                <div class="cards">
                    <div class="card-img">
                        <img src="./asset/images/bus.png" alt="Bus">
                    </div>
                    <div class="blog-title">
                        <h1 class="md-heading">Buses</h1>
                    </div>
                    <a href=""><button class="btn ">Know More</button></a>
                </div>

            </div>
        </div>

        <!-- Process  -->
        <div class="process-container Processmap">
            <h1 class="lg-heading">
                Process to Book
            </h1>
            <img src="./asset/images/map.jpg" alt="map" class="container">
        </div>


        <!-- Packages -->
        <div class="otherveliches Yatra">
            <h1 class="lg-heading">
                Our Packages
            </h1>
            <?php
            // require_once('./Packages/packageDb.php');
            require_once('./Packages/packageDb.php');
            $query = "SELECT * FROM packages where category ='seasonal'";
            $result = mysqli_query($con, $query);

            if (!$result) {
                die('Error: ' . mysqli_error($con));
            }
            ?>

            <div class="container packageContainer">
                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                <div class="cards packageCard">
                    <div class="pack-img">
                        <?php
                            $imagePath = 'uploads/' . $row['package_image'];
                            if (file_exists($imagePath)) {
                                echo '<img src="' . $imagePath . '" alt="">';
                            } else {
                                echo 'Image file does not exist.';
                            }
                            ?>
                    </div>
                    <div class="packDesc">
                        <h3>
                            <?php echo $row['from_location']; ?> to
                            <?php echo $row['to_location']; ?>
                        </h3>
                        <h1 class="lg-heading">
                            <?php echo $row['price']; ?>/-
                        </h1>
                        <button onclick="redirectToPage(<?php echo $row['id']; ?>)" class="btn">Know More</button>
                    </div>
                </div>
                <?php
                }
                ?>
            </div>

            <a href="./Packages/packagesOffer.php"><button class="btn ">Our More Packages</button></a>

        </div>

        <!-- Offers -->



        <!-- Why Ride with Us -->

        <div class="process-container">
            <h1 class="lg-heading">
                Why Ride with Us
            </h1>
            <div class="container featuresContainer">
                <div class="cards featureCard">
                    <div class="featureImg">
                        <img src="./asset/images/carFeature.png" alt="Car">
                    </div>
                    <div class="feature">
                        <h4>Unlimited km to drive</h4>
                    </div>
                </div>

                <div class="cards featureCard">
                    <div class="featureImg">
                        <img src="./asset/images/cityFeature.png" alt="City">
                    </div>
                    <div class="feature">
                        <h4>100+ Locations in Pune City</h4>
                    </div>
                </div>

                <div class="cards featureCard">
                    <div class="featureImg">
                        <img src="./asset/images/earth.png" alt="earth">
                    </div>
                    <div class="feature">
                        <h4>Anywhere delivery in <br> India</h4>
                    </div>
                </div>

                <div class="cards featureCard">
                    <div class="featureImg">
                        <img src="./asset/images/privacy.png" alt="privacy">
                    </div>
                    <div class="feature">
                        <h4>Privacy & freedom</h4>
                    </div>
                </div>
            </div>
        </div>

        <!-- -------------------Feedback section ------------------------------->
        <div class="Feedback-section">
            <h1 class="lg-heading">Add A word..</h1>
            <div class="container">
                <div class="form">
                    <form action="home.php" class="form" method="POST">
                        <input type="text" name="fName" id="fName" placeholder="Enter Your Name" required>

                        <input type="email" name="fEmail" id="fMail" placeholder="Enter Your Email" required>

                        <input type="tel" id="fPhoneNO" name="fPhoneNO" placeholder="Enter Your Phone Number"
                            pattern="[0-9]{10}" title="Enter a valid 10-digit phone number" required />

                        <textarea id="message" rows="4" placeholder="Write Something" name="feedback"></textarea>

                        <button type="submit" class="explore-btn">Send</button>
                    </form>
                </div>
                <div class="cont-img">
                    <!-- <img src="https://img.freepik.com/free-vector/customers-like-video-with-experts-modern-car-review-with-rating-stars-car-review-video-test-drive-channel-auto-video-advertising-concept_335657-2249.jpg?size=626&ext=jpg&ga=GA1.1.1443021671.1690553149&semt=ais"
                    alt=""> -->
                    <img src="./asset/images/about.png" alt="">
                </div>
            </div>
        </div>

        <br><br><br><br><br><br><br><br>


        <!-- Footer -->

        <div class="footer-section">
            <div class="footer-item footerHeading">
                <h1 class="extra-lg">
                    Continue to Live Always.
                </h1>
            </div>

            <div class="footer-item">
                <h2>Company</h2>
                <p><a href="./aboutUs/aboutus.php"> About Us</a></p>
                <p><a href="./contact/contact.php"> Contact Us</a></p>
                <p><a href="./ourServices/ourServices.php"> Our Services</a></p>
                <p><a href=""> Privacy Policy</a></p>
                <p><a href=""> FAQ</a></p>
                <p><a href="admin/adminlogin.php"> Admin login</a></p>

            </div>

            <div class="footer-item social">
                <h2> Follow Us </h2>
                <ul>
                    <li> <i class="fa-brands fa-instagram"></i> </li>
                    <li> <i class="fa-brands fa-linkedin-in"></i> </li>
                    <li> <i class="fa-brands fa-youtube"></i> </li>
                    <li> <i class="fa-brands fa-twitter"></i> </li>
                </ul>
            </div>
        </div>

        <script>
        // Optionally, you can add the following JavaScript to disable keyboard input
        document.getElementById('date-time').addEventListener('keydown', function(e) {
            e.preventDefault();
        });
        </script>
        <!-- redirect to next page -->
        <script>
        function redirectToPage(id) {
            window.location.href = './Packages/packDesc.php?id=' + id;
        }
        </script>

        <!-- ----------------------Explore button script--------------------- -->
        <!-- <script type="text/javascript">
            function redirectPage() {
                var category = document.getElementById("Category").value;
        if (category === "Seden") {
            window.location.href = 'seden.php'; // Assuming seden.php is the page with Seden cards
        } else if (category === "Prime Seden") {
            window.location.href = 'prime_seden.php'; // Assuming prime_seden.php is the page with Prime Seden cards
        } else if (category === "Traveller") {
            window.location.href = 'traveller.php'; // Assuming traveller.php is the page with Traveller cards
        }
            }
        </script> -->
</body>

</html>