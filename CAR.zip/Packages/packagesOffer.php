<?php
// require_once('./Packages/packageDb.php');
require_once('./packageDb.php');
$query = "SELECT * FROM packages ";
$result = mysqli_query($con, $query);

if (!$result) {
    die('Error: ' . mysqli_error($con));
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Packages/packages.css">
    <title>Packages & Deals</title>
    <script>
        function redirectToPage(id) {
            window.location.href = 'packDesc.php?id=' + id;
        }
    </script>
</head>

<body>
    <!-- navbar -->

    <?php
    include("../asset/navbar/navbar.php");
    ?>

    <div class="package-bg">
        <img src="../Packages/images/packageBg.jpg" alt="">
    </div>
    <section class="packages-sec">

        <h1 class="lg-heading packHead">Hot Picks: Trendy Travel Packages!</h1>
        <div class="container pack-cont">
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <div class="cards packageCard">
                    <div class="pack-img">
                        <?php
                        $imagePath =  $row['package_image'];
                        if (file_exists($imagePath)) {
                            echo '<img src="' . $imagePath . '" alt="">';
                        } else {
                            echo '<p class="error-msg">Image file does not exist.</p>';
                        }
                        // echo "console error";
                        
                        ?>

                    </div>
                    <div class="packDesc">
                        <h3>
                            <?php echo $row['from_location']; ?> to
                            <?php echo $row['to_location']; ?>
                        </h3>
                        <h1 class="lg-heading">
                            <?php echo $row['price']; ?>/-
                        </h1>
                        <button onclick="redirectToPage(<?php echo $row['id']; ?>)" class="btn">Know More</button>
                    </div>
                </div>
                <?php
            }
            ?>

        </div>
    </section>


    <?php
    include("../asset/footer/footer.php");
    ?>

</body>

</html>
