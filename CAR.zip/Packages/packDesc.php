<?php
// Assuming $con is defined elsewhere in your code for database connection
require_once('./packageDb.php');

// Check if the package ID is set in the URL
if (isset($_GET['id'])) {
    $packageId = mysqli_real_escape_string($con, $_GET['id']);

    // Fetch package details from the database
    $query = "SELECT  * FROM packages WHERE id = $packageId";
    $result = mysqli_query($con, $query);

    if ($result) {
        $package = mysqli_fetch_assoc($result);
    } else {
        die('Error: ' . mysqli_error($con));
    }
} else {
    // Redirect to the main page if the package ID is not set
    header('Location: home.php');
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Packages/packages.css">
    <title>
        <?php echo $package['from_location'] . ' to ' . $package['to_location']; ?> Details
    </title>
</head>

<body>
    <?php
    include("../asset/navbar/navbar.php");
    ?>
    <div class="container pack-container">
        <div class="pack-img">
            <!-- <img src="<?php echo $package['package_image']; ?>" alt=""> -->
            <?php
            $imagePath = $package['package_image'];
            if (file_exists($imagePath)) {
                echo '<img src="' . $imagePath . '" alt="">';
            } else {
                echo 'Image file does not exist.';
            }
            ?>
        </div>
    </div>
    <!-- title -->
    <div class="packtitle">
        <div class="pack-container">
            <h1 class="lg-heading packHead">
                <?php echo $package['package_title']; ?> Package Details
            </h1>
            <div class="packDesci">
                <h4>
                    <?php echo $package['from_location']; ?> to
                    <?php echo $package['to_location']; ?>
                </h4>
            </div>
            <div class="packDate">
                <h4><span class="nextDate">Next Available:-</span>
                    <?php
                    $journeyDate = $package['journey_date'];
                    echo date('d M y', strtotime($journeyDate));
                    ?>
                </h4>
            </div>
        </div>
    </div>

    <!-- Price&Booking -->
    <div class="pack-container price-section">
        <div class="packBook-cont">
            <div class="pricePack">
                <p>Starting From</p>
                <p>
                    <?php echo $package['price']; ?>/-
                </p>
            </div>
            <div class="bookBtn btn">
                Book Now
            </div>
        </div>
        <!-- OverView -->
        <div class="packOverview">
            <h2 class="md-heading">Overview:-</h2>
            <p>
                <?php echo $package['description']; ?>
            </p>
        </div>
    </div>
        <!-- Terms & Condition -->
        <div class="termsCondition">
            <div class="pack-container">
                <h2 class="md-heading md-white">Terms & Conditions:-</h2>
            </div>
        </div>
    <div class="packTerms">
        <div class="pack-container">
            <ol>
                <?php if (!empty($package['termsAndCondition1'])): ?>
                    <li>
                        <?php echo $package['termsAndCondition1']; ?>
                    </li>
                <?php endif; ?>
                <?php if (!empty($package['termsAndCondition2'])): ?>
                    <li>
                        <?php echo $package['termsAndCondition2']; ?>
                    </li>
                <?php endif; ?>
                <?php if (!empty($package['termsAndCondition3'])): ?>
                    <li>
                        <?php echo $package['termsAndCondition3']; ?>
                    </li>
                <?php endif; ?>
                <?php if (!empty($package['termsAndCondition4'])): ?>
                    <li>
                        <?php echo $package['termsAndCondition4']; ?>
                    </li>
                <?php endif; ?>
                <?php if (!empty($package['termsAndCondition5'])): ?>
                    <li>
                        <?php echo $package['termsAndCondition5']; ?>
                    </li>
                <?php endif; ?>
                <?php if (!empty($package['termsAndCondition6'])): ?>
                    <li>
                        <?php echo $package['termsAndCondition6']; ?>
                    </li>
                <?php endif; ?>
                <?php if (!empty($package['termsAndCondition7'])): ?>
                    <li>
                        <?php echo $package['termsAndCondition7']; ?>
                    </li>
                <?php endif; ?>
                <?php if (!empty($package['termsAndCondition8'])): ?>
                    <li>
                        <?php echo $package['termsAndCondition8']; ?>
                    </li>
                <?php endif; ?>
                <?php if (!empty($package['termsAndCondition9'])): ?>
                    <li>
                        <?php echo $package['termsAndCondition9']; ?>
                    </li>
                <?php endif; ?>
                <?php if (!empty($package['termsAndCondition10'])): ?>
                    <li>
                        <?php echo $package['termsAndCondition10']; ?>
                    </li>
                <?php endif; ?>
            </ol>
        </div>
    </div>
    <br><br><br><br><br><br><br><br><br>

    <?php
    include("../asset/footer/footer.php");
    ?>
</body>

</html>