<?php
$con = mysqli_connect("localhost","root","","journey");
if (!$con) {
    die("Connection failed:");
}


?>