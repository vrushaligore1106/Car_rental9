<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "journey";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM registration_form WHERE email = '$email' LIMIT 1";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $user_data = mysqli_fetch_assoc($result);
        $_SESSION['login'] = $user_data['userID'];                         //session used
        $_SESSION['fullName'] = $user_data['fullName'];     // Storing full name in session
        $_SESSION['submit'] = $_POST['email'];
        echo "<script type='text/javascript'>document.location='../home.php'</script>";
    } else {
        echo "<script>alert('Incorrect user or password')</script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Login Form in HTML CSS</title>
    <link rel="stylesheet" href="../User/Userlogin.css" />
    <style>

    </style>
</head>

<body>


    <div>
        <?php
        include("../asset/navbar/navbar.php");
        ?>
    </div>
    <div class="outer-div">
        <section class="container">
            <div class="container-form">
                <form action="Userlogin.php" method="POST" class="form">
                    <header>Sign In</header>
                    <div class="input-box">
                        <label>Enter Your Email</label>
                        <input type="text" placeholder="Enter Email" name="email" autocomplete="off" required />
                    </div>

                    <div class="input-box">
                        <label>Enter Your Password</label>
                        <input type="password" placeholder="Password" name="password" autocomplete="off" required />
                    </div>
                    <br>
                    <button type="submit">Sign In</button>
                    <p class="Sign">If you don’t have an account<br>Create Now! <a href="UserRegistration.php"
                            class="Login">Register</a></p>
                </form>
                <div class=" ">
                    <img src="../User/Image/about.png" alt="login" style="height:300px;width:400px">
                </div>
            </div>
        </section>
    </div>

    <div class="">
        <?php
        include("../asset/footer/footer.php");
        ?>
    </div>
</body>

</html>