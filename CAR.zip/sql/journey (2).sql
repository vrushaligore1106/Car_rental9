-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 14, 2024 at 06:21 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `journey`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_information`
--

CREATE TABLE `booking_information` (
  `id` int(11) NOT NULL,
  `Cname` varchar(100) NOT NULL,
  `Cemail` varchar(255) NOT NULL,
  `Cmobile` int(10) NOT NULL,
  `pick_location` varchar(500) NOT NULL,
  `category` varchar(255) NOT NULL,
  `drop_location` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `pick_time` time NOT NULL,
  `distance` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_information`
--

INSERT INTO `booking_information` (`id`, `Cname`, `Cemail`, `Cmobile`, `pick_location`, `category`, `drop_location`, `date`, `pick_time`, `distance`, `price`) VALUES
(45, '', '', 0, 'puneRailwayStation', '2to4', 'saiChowk', '2024-02-14', '00:12:00', '', 0),
(46, '', '', 0, 'puneRailwayStation', '2to4', 'saiChowk', '2024-02-28', '03:12:00', '', 0),
(47, '', '', 0, 'puneRailwayStation', '2to4', 'saiChowk', '2024-02-21', '04:14:00', '', 0),
(48, '', '', 0, 'puneRailwayStation', '2to4', 'saiChowk', '2024-02-28', '02:19:00', '', 0),
(49, '', '', 0, 'puneRailwayStation', '2to4', 'saiChowk', '2024-02-28', '02:19:00', '', 0),
(50, '', '', 0, 'puneRailwayStation', '2to4', 'saiChowk', '2024-02-28', '00:25:00', '', 0),
(51, '', '', 0, 'puneRailwayStation', '2to4', 'saiChowk', '2024-03-05', '00:26:00', '', 0),
(52, '', '', 0, 'elproCitySquare', '2to4', 'puneAirport', '2024-02-15', '05:28:00', '', 0),
(53, '', '', 0, 'puneAirport', 'Traveller', 'elproCitySquare', '2024-02-29', '11:35:00', '', 0),
(54, '', '', 0, 'puneAirport', '7to9', 'shivajinagarBusStand', '2024-02-13', '03:35:00', '', 0),
(55, '', '', 0, 'puneRailwayStation', '7to9', 'saiChowk', '2024-02-22', '01:43:00', '', 0),
(56, '', '', 0, 'puneRailwayStation', '7to9', 'saiChowk', '2024-02-22', '01:43:00', '', 0),
(57, '', '', 0, 'elproCitySquare', 'Buses', 'shivajinagarBusStand', '2024-02-29', '11:53:00', '', 0),
(58, '', '', 0, 'puneRailwayStation', '2to4', 'saiChowk', '2024-02-15', '01:53:00', '', 0),
(59, '', '', 0, 'puneRailwayStation', 'Traveller', 'saiChowk', '2024-02-15', '01:53:00', '', 0),
(60, '', '', 0, 'puneRailwayStation', 'Traveller', 'saiChowk', '2024-02-15', '01:53:00', '', 0),
(61, '', '', 0, 'puneRailwayStation', 'Traveller', 'saiChowk', '2024-02-15', '01:53:00', '', 0),
(62, '', '', 0, 'puneRailwayStation', '7to9', 'saiChowk', '2024-02-15', '01:53:00', '', 0),
(63, '', '', 0, 'puneRailwayStation', '7to9', 'saiChowk', '2024-02-15', '01:53:00', '', 0),
(64, '', '', 0, 'puneRailwayStation', '7to9', 'saiChowk', '2024-02-15', '01:53:00', '', 0),
(65, '', '', 0, 'puneRailwayStation', '7to9', 'saiChowk', '2024-02-15', '01:53:00', '', 0),
(66, '', '', 0, 'puneRailwayStation', '7to9', 'saiChowk', '2024-02-15', '01:53:00', '', 0),
(67, '', '', 0, 'puneRailwayStation', '7to9', 'saiChowk', '2024-02-15', '01:53:00', '', 0),
(68, '', '', 0, 'puneRailwayStation', '2to4', 'saiChowk', '0000-00-00', '00:00:00', '', 0),
(69, '', '', 0, 'puneRailwayStation', '2to4', 'saiChowk', '0000-00-00', '00:00:00', '', 0),
(70, '', '', 0, 'puneRailwayStation', '7to9', 'elproCitySquare', '0000-00-00', '00:00:00', '', 0),
(71, '', '', 0, 'puneRailwayStation', '2to4', 'saiChowk', '0000-00-00', '00:00:00', '', 0),
(72, '', '', 0, 'puneRailwayStation', '2to4', 'saiChowk', '0000-00-00', '00:00:00', '', 0),
(73, '', '', 0, 'puneRailwayStation', 'Seden', 'saiChowk', '0000-00-00', '00:00:00', '', 0),
(74, '', '', 0, 'puneRailwayStation', 'Seden', 'saiChowk', '2024-02-14', '14:52:00', '', 0),
(75, '', '', 0, 'puneRailwayStation', 'Seden', 'saiChowk', '2024-02-14', '14:52:00', '', 0),
(76, '', '', 0, 'puneRailwayStation', 'Seden', 'saiChowk', '0000-00-00', '00:00:00', '', 0),
(77, '', '', 0, 'puneRailwayStation', 'Seden', 'saiChowk', '0000-00-00', '00:00:00', '', 0),
(78, '', '', 0, 'puneRailwayStation', 'Seden', 'saiChowk', '0000-00-00', '00:00:00', '', 0),
(79, '', '', 0, 'elproCitySquare', 'Traveller', 'chinchvadStation', '0000-00-00', '00:00:00', '', 0),
(80, '', '', 0, 'elproCitySquare', 'Traveller', 'chinchvadStation', '0000-00-00', '00:00:00', '', 0),
(81, '', '', 0, 'elproCitySquare', 'Traveller', 'chinchvadStation', '2024-02-21', '17:30:00', '', 0),
(82, '', '', 0, 'elproCitySquare', 'Traveller', 'chinchvadStation', '2024-02-21', '17:30:00', '', 0),
(83, '', '', 0, 'elproCitySquare', 'Traveller', 'chinchvadStation', '2024-02-21', '17:30:00', '', 0),
(84, '', '', 0, 'elproCitySquare', 'Traveller', 'chinchvadStation', '2024-02-21', '17:30:00', '', 0),
(85, '', '', 0, 'elproCitySquare', 'Traveller', 'chinchvadStation', '2024-02-21', '17:30:00', '', 0),
(86, '', '', 0, 'puneRailwayStation', 'Seden', 'saiChowk', '0000-00-00', '00:00:00', '', 0),
(87, '', '', 0, 'puneRailwayStation', 'Seden', 'pune', '0000-00-00', '00:00:00', '', 0),
(88, '', '', 0, 'dehuroad', 'Traveller', 'chinchwad', '2024-02-15', '18:44:00', '', 0),
(89, '', '', 0, 'kamshet', 'Seden', 'pune', '2024-02-14', '16:47:00', '', 0),
(90, 'HR', 'h@gmail.com', 2147483647, 'talegaon', '', 'pune', '0000-00-00', '00:00:00', '', 0),
(91, 'HR', 'h@gmail.com', 2147483647, 'talegaon', '', 'pune', '0000-00-00', '00:00:00', '', 0),
(92, 'HR', 'h@gmail.com', 2147483647, 'talegaon', '', 'pune', '0000-00-00', '00:00:00', '', 0),
(93, 'HR', 'h@gmail.com', 2147483647, 'talegaon', '', 'pune', '0000-00-00', '00:00:00', '', 0),
(94, 'HR', 'h@gmail.com', 2147483647, 'kamshet', '', 'pune', '0000-00-00', '00:00:00', '', 0),
(95, '', '', 0, 'lonavala', 'Seden', 'pune', '2024-02-14', '16:47:00', '', 0),
(96, '', '', 0, 'dehuroad', 'Traveller', 'chinchwad', '2024-02-16', '00:30:00', '', 0),
(97, '', '', 0, 'dehuroad', 'Traveller', 'chinchwad', '2024-02-16', '00:30:00', '', 0),
(98, '', '', 0, 'dehuroad', 'Traveller', 'chinchwad', '2024-02-16', '00:30:00', '', 0),
(99, '', '', 0, 'talegaon', 'Buses', 'pune', '2024-02-16', '00:30:00', '', 0),
(101, 'HR', 'h@gmail.com', 2147483647, 'dehuroad', '', 'pune', '0000-00-00', '00:00:00', '', 0),
(102, '', '', 0, 'dehuroad', 'Seden', 'pune', '2024-02-15', '23:26:00', '', 0),
(103, '', '', 0, 'kamshet', 'Seden', 'pune', '2024-02-29', '13:29:00', '', 0),
(104, '', '', 0, 'kamshet', 'Seden', 'pune', '2024-02-29', '13:29:00', '', 0),
(105, '', '', 0, 'kamshet', 'Traveller', 'pune', '2024-02-29', '13:29:00', '', 0),
(106, '', '', 0, 'kamshet', 'Seden', 'pune', '2024-02-29', '13:29:00', '', 0),
(107, '', '', 0, 'kamshet', 'Traveller', 'pune', '2024-02-29', '13:29:00', '', 0),
(108, '', '', 0, 'dehuroad', 'Traveller', 'pune', '2024-02-29', '13:29:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `phone`, `email`, `city`, `message`) VALUES
(1, 'Vaibhav Gholap', '9309595723', 'vaibhavgholap365@gmail.com', 'Beed', 'ajhfeshf'),
(2, 'rushi', '9309595723', 'vaibhavgholap365@gmail.com', 'Beed', 'shdfisdhfhof');

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `driverId` int(10) NOT NULL,
  `dName` varchar(255) NOT NULL,
  `dEmail` varchar(255) NOT NULL,
  `dPhone_number` varchar(255) NOT NULL,
  `dBirth_date` date NOT NULL,
  `photo_path` varchar(255) NOT NULL,
  `license_path` varchar(255) NOT NULL,
  `adhar_path` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`driverId`, `dName`, `dEmail`, `dPhone_number`, `dBirth_date`, `photo_path`, `license_path`, `adhar_path`) VALUES
(1, 'Testing', 'testing@gmail.com', '7890123456', '2024-01-23', 'uploads/5stars.png', 'uploads/5stars.png', 'uploads/5stars.png'),
(2, 'Testing', 'testing1@gmail.com', '7890123456', '2024-01-16', 'uploads/7 -9  seater.png', 'uploads/banaras.jpg', 'uploads/bike.png');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `fId` int(10) NOT NULL,
  `fName` varchar(255) NOT NULL,
  `fEmail` varchar(255) NOT NULL,
  `fPhoneNO` varchar(255) NOT NULL,
  `feedback` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fId`, `fName`, `fEmail`, `fPhoneNO`, `feedback`) VALUES
(1, 'testing', 'testing@gmail.com', '1234567890', 'testing'),
(2, 'testing', 'testing@gmail.com', '1234567890', 'testing');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(50) NOT NULL,
  `pick` varchar(255) NOT NULL,
  `dropp` varchar(255) NOT NULL,
  `distance` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `pick`, `dropp`, `distance`) VALUES
(1, 'kamshet', 'pune', 50),
(2, 'lonavala', 'pune', 60),
(3, 'dehuroad', 'pune', 30),
(4, 'chinchwad', 'pune', 20),
(5, 'talegaon', 'chinchwad', 20);

-- --------------------------------------------------------

--
-- Table structure for table `offer`
--

CREATE TABLE `offer` (
  `offerid` int(200) NOT NULL,
  `offername` varchar(100) NOT NULL,
  `discount` varchar(5) NOT NULL,
  `CouponCode` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `offer`
--

INSERT INTO `offer` (`offerid`, `offername`, `discount`, `CouponCode`) VALUES
(1, 'offer bhaiya', '2', 'hoja appleid');

-- --------------------------------------------------------

--
-- Table structure for table `ownerregistration`
--

CREATE TABLE `ownerregistration` (
  `id` int(11) NOT NULL,
  `ownerName` varchar(255) NOT NULL,
  `ownerEmail` varchar(255) NOT NULL,
  `ownerPhoneNo` varchar(20) NOT NULL,
  `ownerDocu` varchar(50) NOT NULL,
  `ownerDocuImg` varchar(255) NOT NULL,
  `ownerPassword` varchar(255) NOT NULL,
  `confirmPassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ownerregistration`
--

INSERT INTO `ownerregistration` (`id`, `ownerName`, `ownerEmail`, `ownerPhoneNo`, `ownerDocu`, `ownerDocuImg`, `ownerPassword`, `confirmPassword`) VALUES
(16, 'vaibhav', 'vaibhav@gmail.com', '9999999999', 'aadhaarCard', 'uploads/The Press Studios 17.png', 'Vaibhav@123', 'Vaibhav@123');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `package_title` varchar(255) NOT NULL,
  `from_location` varchar(255) NOT NULL,
  `to_location` varchar(255) NOT NULL,
  `journey_date` date NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text NOT NULL,
  `termsAndCondition1` varchar(100) DEFAULT NULL,
  `termsAndCondition2` varchar(100) DEFAULT NULL,
  `termsAndCondition3` varchar(100) DEFAULT NULL,
  `termsAndCondition4` varchar(100) DEFAULT NULL,
  `termsAndCondition5` varchar(255) NOT NULL,
  `termsAndCondition6` varchar(255) NOT NULL,
  `termsAndCondition7` varchar(255) NOT NULL,
  `termsAndCondition8` varchar(255) NOT NULL,
  `termsAndCondition9` varchar(255) NOT NULL,
  `termsAndCondition10` varchar(255) NOT NULL,
  `coupon_code` varchar(255) NOT NULL,
  `category` varchar(50) NOT NULL,
  `package_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`, `package_title`, `from_location`, `to_location`, `journey_date`, `price`, `description`, `termsAndCondition1`, `termsAndCondition2`, `termsAndCondition3`, `termsAndCondition4`, `termsAndCondition5`, `termsAndCondition6`, `termsAndCondition7`, `termsAndCondition8`, `termsAndCondition9`, `termsAndCondition10`, `coupon_code`, `category`, `package_image`) VALUES
(1, '', 'Kashmir', 'karad', 'mumbai', '2024-01-11', 99999999.99, 'jgkj', '', '', '', '', '', '', '', '', '', '', '', 'monthly', 'uploads/D.drawio'),
(2, '', 'Kashmir', 'karad', 'mumbai', '2024-01-11', 99999999.99, 'jgkj', '', '', '', '', '', '', '', '', '', '', '', 'monthly', 'uploads/D.drawio');

-- --------------------------------------------------------

--
-- Table structure for table `prime_seden`
--

CREATE TABLE `prime_seden` (
  `id` int(10) NOT NULL,
  `Image` varchar(4000) NOT NULL,
  `vehicle_name` varchar(255) NOT NULL,
  `toll` int(255) NOT NULL,
  `vehicle_category` varchar(255) NOT NULL,
  `price_per_km` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prime_seden`
--

INSERT INTO `prime_seden` (`id`, `Image`, `vehicle_name`, `toll`, `vehicle_category`, `price_per_km`) VALUES
(1, 'https://i.postimg.cc/W4WxPzVG/Prime-Seden.png', 'Ertiga', 400, 'Prime Seden', 16),
(2, 'https://i.postimg.cc/15KkHsXZ/innova.png', 'Innova', 400, 'Prime Seden', 18);

-- --------------------------------------------------------

--
-- Table structure for table `registration_form`
--

CREATE TABLE `registration_form` (
  `userID` int(10) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `birthDate` date NOT NULL,
  `gender` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `confirmPassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration_form`
--

INSERT INTO `registration_form` (`userID`, `fullName`, `email`, `phoneNumber`, `birthDate`, `gender`, `password`, `confirmPassword`) VALUES
(11, 'vaibhav', 'v@gmail.com', '9999999999', '2024-01-30', 'Male', 'Vaibhav@123', 'Vaibhav@123'),
(12, 'kaustubh', 'k@gmail.com', '9999999999', '2024-02-06', 'Male', 'Kaust@123', 'Kaust@123');

-- --------------------------------------------------------

--
-- Table structure for table `seden`
--

CREATE TABLE `seden` (
  `id` int(255) NOT NULL,
  `Image` varchar(4000) NOT NULL,
  `vehicle_name` varchar(255) NOT NULL,
  `toll` int(255) NOT NULL,
  `vehicle_category` varchar(255) NOT NULL,
  `price_per_km` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seden`
--

INSERT INTO `seden` (`id`, `Image`, `vehicle_name`, `toll`, `vehicle_category`, `price_per_km`) VALUES
(2, 'https://i.postimg.cc/T3vRZLPZ/Seden.png', 'Swift Desire', 300, 'Seaden', '12'),
(3, 'https://i.postimg.cc/T3vRZLPZ/Seden.png', 'Aura', 250, 'Seden', '11'),
(4, 'https://i.postimg.cc/T3vRZLPZ/Seden.png', 'Glanza', 350, 'Seden', '13');

-- --------------------------------------------------------

--
-- Table structure for table `traveller`
--

CREATE TABLE `traveller` (
  `id` int(10) NOT NULL,
  `Image` varchar(4000) NOT NULL,
  `vehicle_name` varchar(255) NOT NULL,
  `toll` int(255) NOT NULL,
  `vehicle_category` varchar(255) NOT NULL,
  `price_per_km` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `traveller`
--

INSERT INTO `traveller` (`id`, `Image`, `vehicle_name`, `toll`, `vehicle_category`, `price_per_km`) VALUES
(1, 'https://i.postimg.cc/vB2ZNf35/mini-removebg-preview.png', 'Mini Traveller', 600, 'Mini Traveller', 22),
(2, 'https://i.postimg.cc/G3kcY01k/sleeper.png', 'Bus (25 Seater)', 700, 'Traveller', 25);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking_information`
--
ALTER TABLE `booking_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`driverId`),
  ADD UNIQUE KEY `dEmail` (`dEmail`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`fId`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offer`
--
ALTER TABLE `offer`
  ADD PRIMARY KEY (`offerid`);

--
-- Indexes for table `ownerregistration`
--
ALTER TABLE `ownerregistration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prime_seden`
--
ALTER TABLE `prime_seden`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration_form`
--
ALTER TABLE `registration_form`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `seden`
--
ALTER TABLE `seden`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `traveller`
--
ALTER TABLE `traveller`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking_information`
--
ALTER TABLE `booking_information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `driver`
--
ALTER TABLE `driver`
  MODIFY `driverId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `fId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `offer`
--
ALTER TABLE `offer`
  MODIFY `offerid` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ownerregistration`
--
ALTER TABLE `ownerregistration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `prime_seden`
--
ALTER TABLE `prime_seden`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `registration_form`
--
ALTER TABLE `registration_form`
  MODIFY `userID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `seden`
--
ALTER TABLE `seden`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `traveller`
--
ALTER TABLE `traveller`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
