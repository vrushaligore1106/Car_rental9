<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./asset/Styles/home.css">
  <link rel="icon" type="image/x-icon" href="./asset/images/logo.png">
  <title>About Us </title>
  <style>
    header {
      background-color: #000000;
      color: #fff;
      text-align: center;
      padding: 100px;
    }


    nav {
      display: flex;
      background-color: #eee;
    }



    nav div {
      display: flex;
      align-items: center;
      margin-left: 15px;
    }


    section {
      padding: 20px;
      text-align: left;

    }

    footer {
      background-color: #180047;
      color: #999494;
      text-align: center;
      padding: 10px;
    }

    footer a {
      color: #e2e2e2;
      text-decoration: none;
    }

    .happyClients-section {
      text-align: center;
      padding: 20px;
      background-color: #f5f5f5;
    }

    .lg-heading {
      font-size: 2em;
      margin-bottom: 20px;
      color: #333;
    }

    .wrapper {
      max-width: 600px;
      margin: 0 auto;
      position: relative;
    }


    .card {

      box-sizing: border-box;
      margin-bottom: 20px;
      /* Adjust margin as needed */
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .stars {
      width: 100px;
      margin: 10px 0;
    }

    img {
      padding-top: 15PX;
      float: right;
      width: 300PX;
      height: 200PX;
    }
  </style>

</head>

<body>
  <header>
    <h1>JOURNEY LIVE</h1>
  </header>

  <nav>
    <div>
      <span>ABOUT JOURNEY LIVE</span>
    </div>
  </nav>

  <section class="container about-con">
    <div class="left-about">
      <h1 class="lg-heading">WHO ARE WE :</h1>
      <p>

        Welcome to Journey Live, where we transform ordinary trips into extraordinary adventures. Our commitment is to
        elevate your travel experience by providing unparalleled bike, car, and bus rental services. At the core of
        Journey Live is a customer-centric approach, ensuring that your journey is not just a mode of transportation but a
        seamless and exceptional exploration. We take pride in our diverse fleet, offering the perfect vehicle for every
        occasion, whether it's a romantic getaway, urban exploration, or a group adventure. Utilizing cutting-edge
        technology, our user-friendly online platform simplifies the booking process, emphasizing convenience for our
        valued customers. Sustainability is ingrained in our values, with a dedication to eco-friendly practices to
        minimize our environmental impact. Beyond transportation, Journey Live is an active participant in the communities
        we serve, contributing to local events and charitable causes. When you choose Journey Live, you're not just
        renting a vehicle; you're embarking on a journey where every road becomes a canvas for your next remarkable story.
        Your adventure begins here with Journey Live, your trusted companion in exploration and discovery.</p>
  
    </div>
    <div class="right-about">
      <img src="./asset/images/homeCar.png"></IMG>

    </div>
   </section>
   
   <section class="container">
    <h2>Our Mission :</h2>

    <p>
      At Journey Live, our mission is to redefine the travel experience for our customers. We are dedicated to going
      beyond the conventional notions of transportation, striving to be your trusted companion on every journey.
      Customer satisfaction lies at the core of our mission, and we tirelessly work to exceed expectations by
      prioritizing comfort, convenience, and safety. Our commitment extends to maintaining a diverse fleet of vehicles,
      ensuring that whether it's a solo escapade, a family adventure, or a group outing, we have the perfect ride for
      every occasion. Leveraging cutting-edge technology, our user-friendly online platform simplifies the booking
      process, making it seamless and efficient. Sustainability is not just a buzzword for us; it's a fundamental aspect
      of our mission. We actively pursue eco-friendly practices, from our vehicle choices to minimizing our
      environmental footprint. As an integral part of the communities we serve, our mission extends beyond
      transportation. Through community engagement, we participate in local events, support charitable causes, and
      strive to make a positive impact. Above all, our mission is to help you create memorable journeys — turning each
      road traveled into a story worth remembering. Choose Journey Live, and let us embark on this mission together,
      enhancing your adventures and making every trip an unforgettable experience.</p>
    <h2>Customer-Centric Service :</h2>
    <p>At Journey Live, customer satisfaction is at the heart of everything we do. Our dedicated customer support team
      is available 24/7 to assist you with any inquiries or concerns. Your feedback is not just welcomed; it's integral
      to our continuous efforts to improve and tailor our services to exceed your expectations.
      Our customer-centric approach begins with a diverse fleet of well-maintained vehicles, catering to various
      preferences and needs. We aim to provide options that align with the unique requirements of our diverse clientele,
      whether it's a sleek car for a romantic getaway, a nimble bike for urban exploration, or a spacious bus for group
      adventures.Our dedication to customer satisfaction extends beyond the transaction. The Journey Live customer
      support team operates around the clock, ready to assist with any inquiries or concerns. We view every interaction
      as an opportunity to enhance your experience, valuing your feedback as an essential tool for continuous
      improvement.

      In essence, our customer-centric service is not just about providing transportation; it's about crafting an
      experience that is tailored to your needs, preferences, and desires. We invite you to choose Journey Live for a
      journey where you are not just a passenger but a valued and cherished part of the adventure. Your satisfaction is
      our mission, and we are committed to making every mile of your journey exceptional</P>
    <h2>Community Connection :</h2>
    <p>Journey Live is not just a service; it's a community. We actively engage with local events, support charitable
      causes, and believe in making a positive impact in the communities we serve. When you choose Journey Live, you're
      not just renting a vehicle; you're becoming part of a community that values shared experiences and adventures.
      Our community connection is not a one-way street; it's a reciprocal relationship. We listen to the needs of the
      communities we operate in, actively engaging with residents and organizations to understand how we can better
      contribute to their well-being. Through collaboration and shared initiatives, we aim to create a positive and
      lasting impact that goes beyond the boundaries of transportation.

      At Journey Live, we invite you to be a part of more than just a ride; join us in building a community where every
      journey is an opportunity to connect, support, and celebrate together. Choose Journey Live for a transportation
      experience that not only takes you places but also brings people together and contributes to the flourishing
      tapestry of the communities we call home.
    </p>
    <h2>Embark on Your Journey with Journey Live :</h2>
    <p>Elevate your adventures with Journey Live, your trusted partner in transportation. Whether you're planning a solo
      escapade, a family vacation, or a corporate outing, we've got the wheels to match your journey. Choose Journey
      Live and let the road be the canvas for your next remarkable story. Your journey begins with us
      From the moment you engage with us, whether through our user-friendly online platform or our dedicated customer
      support, you're welcomed into a community that values your journey as much as you do. "Embark on Your Journey with
      Journey Live" encapsulates our commitment to being more than just a service provider; it's an invitation to become
      a part of something bigger, a collective of explorers and wanderers.

      Our diverse fleet, designed for every occasion and preference, awaits to carry you through the landscapes of your
      dreams. The phrase embodies our pledge to be there with you at every turn, ensuring that your voyage is seamless,
      memorable, and filled with the thrill of discovery.
    </p>
  </section>

  <div class="happyClients-section">
    <h1 class="lg-heading">.......... Our Happy Clients ..........</h1>
    <div class="wrapper container">
      <i id="left" class="fas fa-angle-left"></i>
      <div class="carousel">
        <div class="card">
          <h2>Rohit Dhawan</h2>
          <p>
            " Exceptional experience with journey Live. Seamless online reservation, friendly staff,
            spotless vehicle, transparent pricing, flexible extension, and effortless return. Outstanding
            customer service. Highly recommend for reliable and hassle-free car rentals."
          </p>
        </div>

        <div class="card">
          <h2>Ashwin Patil</h2>
          <p>
            Competitive pricing without hidden fees! I compared several rental services, and Journeylife
            offered
            the best value for money. The quoted price was what I paid, no surprises or unexpected charges.
            Fantastic service! Transparent pricing, friendly staff, and reliable vehicles. Highly recommend!
          </p>
        </div>


        
        <div class="card">
          <h2>Deepti Singh</h2>
          <p>
            Exceptional car rental experience with journey live. Seamless reservation, friendly and
            professional staff, spotless and reliable vehicle. Transparent pricing with no hidden fees.
            Effortless extension process. Hassle-free return. Outstanding customer service. Highly recommend
            for a stress-free</p>
        </div>
      </div>
      <i id="right" class="fas fa-angle-right"></i>
    </div>
  </div>


  <footer>
    <p>&copy; 2024 JOURNEY LIVE | <a href="https://www.youTUBE.com" target="_blank">Visit our website</a></p>
  </footer>

  </script>
</body>

</html>