<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <?php include("../asset/navbar/navbar.php"); ?>
    <h1 class="lg-heading active">Prime Seden (XUV)</h1>
    <div class="container">
        <?php
        $con = mysqli_connect("localhost", "root", "", "journey");
        if (!$con) {
            die("Connection failed:");
        }
        $sql2 = "SELECT * FROM prime_seden";
        $result2 = $con->query($sql2);
        while ($row2 = mysqli_fetch_assoc($result2)) {
            ?>
        <div class="cards">
            <div class="images">
                <img src="<?php echo $row2['Image']; ?>" alt="" height="250">
            </div>
            <div class="details">
                <!-- <h1 class="lg-heading"><?php echo $row2['id']; ?></h1> -->
                <h1 class="lg-heading"><?php echo $row2['vehicle_name']; ?></h1>
                <h1 class="lg-heading toll">
                    <P>Toll Prices: <?php echo $row2['toll']; ?></P>
                </h1>
                <h3 class="lg-heading">Rs:- <?php echo $row2['price_per_km']; ?> <span class="span">&nbsp;/Per KM</span>
                </h3>
                <button class="btn"
                    onclick="submitForm('<?php echo $row2['vehicle_name']; ?>', '<?php echo $row2['toll']; ?>', '<?php echo $row2['price_per_km']; ?>')">Submit</button>
            </div>
        </div>
        <?php
        }
        ?>
    </div>
    <?php include("../asset/footer/footer.php"); ?>
    <!-- Include jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    function submitForm(vehicle_name, toll, price_per_km) {
        // Collect form data
        var urlParams = new URLSearchParams(window.location.search);
        var formData = {
            Category: urlParams.get('Category'),
            pick_location: urlParams.get('pick_location'),
            drop_location: urlParams.get('drop_location'),
            date: urlParams.get('date'),
            pick_time: urlParams.get('pick_time'),
            distance: urlParams.get('distance'),
            vehicle_name: vehicle_name,
            toll: toll,
            price_per_km: price_per_km
        };

        // Send data to PHP script using AJAX
        $.ajax({
            type: "POST",
            url: "submitdb1.php",
            data: formData,
            success: function(response) {
                window.location.href = '../booking form/booking.php';
            }
        });
    }
    </script>
</body>

</html>