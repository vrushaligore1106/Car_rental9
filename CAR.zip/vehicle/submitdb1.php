<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "journey";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$Category = $_POST['Category'];
$pick_location = $_POST['pick_location'];
$drop_location = $_POST['drop_location'];
$date = $_POST['date'];
$pick_time = $_POST['pick_time'];
$distance = $_POST['distance'];
$vehicle_name = $_POST['vehicle_name'];
$toll = $_POST['toll'];
$price_per_km = $_POST['price_per_km'];

// Insert data into the temp_book table
$sql = "INSERT INTO temp_book (Category, pick_location, drop_location, date, pick_time, distance, vehicle_name, toll, price_per_km)
        VALUES ('$Category', '$pick_location', '$drop_location', '$date', '$pick_time', '$distance', '$vehicle_name', '$toll', '$price_per_km')";

if ($conn->query($sql) === TRUE) {
    echo "Data inserted successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>