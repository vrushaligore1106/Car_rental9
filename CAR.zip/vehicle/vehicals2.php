<?php
// Retrieve the selected category from the query parameter
if (isset($_GET['Category'])) {
    $Category = strtolower(trim($_GET['Category']));

    $Category = $_GET['Category'];
    // Debugging statement
} else {
    // Handle the case when Category is not set
    echo "Category not selected.";
    exit(); // Stop further execution
}

// Include the appropriate PHP file based on the selected category
if ($Category === "Seden") {
    include("seden.php"); // Include PHP file containing seden cards
} elseif ($Category === "Prime Seden") {
    include("prime_seden.php"); // Include PHP file containing prime_seden cards
} elseif ($Category === "Traveller") {
    include("traveller.php"); // Include PHP file containing traveller cards
} else {
    echo "Invalid category selected."; // Handle the case when an invalid category is selected
    exit(); // Stop further execution
}
?>